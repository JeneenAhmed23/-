public class Test {
    public static void main(String[] args) {
        CircularlyLinkedList<Integer>l=new CircularlyLinkedList<>();
        l.addFirst(11);
        l.addLast(12);
        l.addLast(13);
        System.out.println(l.first()+"is the first element before rotation");
        l.rotate();
        System.out.println(l.first()+"is the first element after rotation");
        System.out.println("all elements are : ");
        for (int i = 0; i <l.size() ; i++) {
            System.out.println(l.first());
            l.rotate();

        }

    }
}
