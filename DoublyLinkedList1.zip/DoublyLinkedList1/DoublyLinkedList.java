public class DoublyLinkedList<E>{
    private Node<E>header;
    private Node<E>trailer;
    private int size=0;
    public DoublyLinkedList()
    {
        header=new Node<>(null,null,null);
        trailer= new Node<>(null,header,null);
        header.setNext(trailer);
    }



    //public int size()
    //{return size;}
    public boolean isEmpty(){
        return size==0;}
    public E first()
    {if (isEmpty())return null;
        return header.getNext().getElement();
    }
    public E last()
    {if (isEmpty())return null;
        return trailer.getPrev().getElement();
    }
    private void addBetween(E e,Node<E>p,Node<E>n)
    {
        Node<E>newest= new Node<>(e,p,n);
        p.setNext(newest);
        n.setPrev(newest);
        size++;}
    public void addFirst(E ee)
    {
        addBetween(ee,header,header.next);}
    public void addLast(E ee)
    {
        addBetween(ee,trailer.prev,trailer);
    }
    private E remove(Node<E>x)
    {Node<E>p=x.prev;
        Node<E>n=x.next;
        p.setNext(n);
        n.setPrev(p);
        size--;
        return x.element;}
    public E removeFirst()
    {if (isEmpty())return null;
        return remove(header.next);}
    public E removeLast()
    {if (isEmpty())return null;
        return remove(trailer.prev);}


    //Describe a method for finding the middle node of a doubly linked list with header and trailer sentinels by “link hopping,” and without relying on explicit knowledge of the size of the list. In the case of an even number of nodes, report the node slightly left of center as the “middle
    public Node findMiddleNode() {
        Node slow = header.next;
        Node fast = header.next;

        while (fast != trailer && fast.next != trailer) {
            slow = slow.next;
            fast = fast.next.next;
        }

        return slow;
    }

    //2.	Give an implementation of the size( ) method for the DoublyLinkedList class, assuming that we did not maintain size as an instance variable
    public int size() {
        int sz = 0;
        Node<E> nodes = header.getNext();

        while (nodes != trailer) {
            sz++;
            nodes = nodes.getNext();
        }

        return sz;
    }

    //3.	Implement the equals( ) method for the DoublyLinkedList class.
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof DoublyLinkedList)) {
            return false;
        }

        DoublyLinkedList otherList = (DoublyLinkedList) obj;

        if (this.size() != otherList.size()) {
            return false;
        }

        Node currentNode = this.header.next;
        Node otherNode = otherList.header.next;

        while (currentNode != this.trailer) {
            if (!currentNode.element.equals(otherNode.element)) {
                return false;
            }

            currentNode = currentNode.next;
            otherNode = otherNode.next;
        }

        return true;
    }

    //4.Give an algorithm for concatenating two doubly linked lists L and M, with header and trailer sentinel nodes, into a single list L′
    public DoublyLinkedList concatenateLists(DoublyLinkedList otherList) {
        if (header.next == trailer) {
            // If the first list is empty, return the second list
            return otherList;
        }

        if (otherList.header.next == otherList.trailer) {
            // If the second list is empty, return the first list
            return this;
        }

        Node selfTail = trailer.prev;
        Node otherHead = otherList.header.next;

        selfTail.next = otherHead;
        otherHead.prev = selfTail;

        trailer = otherList.trailer;

        return this;
    }


    //5.Our implementation of a doubly linked list relies on two sentinel nodes, header and trailer, but a single sentinel node that guards both ends of the list should suffice. Reimplement the DoublyLinkedList class using only one sentinel node
   /** public class DoublyLinkedList {
        private Node sentinel;

        public DoublyLinkedList() {
            sentinel = new Node();
            sentinel.next = sentinel;
            sentinel.prev = sentinel;
        }

        private static class Node {
            private Object data;
            private Node next;
            private Node prev;

            public Node() {
            }

            public Node(Object data, Node next, Node prev) {
                this.data = data;
                this.next = next;
                this.prev = prev;
            }
      **/

    //6.Implement a circular version of a doubly linked list, without any sentinels, that supports all the public behaviors of the original as well as two new update methods, rotate( ) and rotateBackward
    public void rotate() {
        if (isEmpty() || size() == 1) {
            return;
        }

        Node<E> lastNode = trailer.getPrev();
        Node<E> firstNode = header.getNext();

        lastNode.setNext(firstNode);
        firstNode.setPrev(lastNode);

        header.setNext(firstNode.getNext());
        firstNode.getNext().setPrev(header);

        firstNode.setNext(trailer);
        trailer.setPrev(firstNode);
    }

    //7.Implement the clone( ) method for the DoublyLinkedList class
    public DoublyLinkedList clone() {
        try {
            DoublyLinkedList cloneList = (DoublyLinkedList) super.clone();
            cloneList.header = null;
            cloneList.trailer = null;

            Node current = header;
            while (current != null) {
                cloneList.addFirst(current.element);
                current = current.next;
            }

            return cloneList;
        } catch (CloneNotSupportedException e) {
            // This should not happen since we implement Cloneable
            throw new RuntimeException(e);
        }
    }
    private static class Node<E>
    {
        E element;
        Node<E>prev;
        Node<E>next;
        public Node(E element, Node<E> prev, Node<E> next) {
            this.element = element;
            this.prev = prev;
            this.next = next;
        }

        public E getElement() {
            return element;
        }

        public void setElement(E element) {
            this.element = element;
        }

        public Node<E> getPrev() {
            return prev;
        }

        public void setPrev(Node<E> prev) {
            this.prev = prev;
        }

        public Node<E> getNext() {
            return next;
        }

        public void setNext(Node<E> next) {
            this.next = next;
        }
    }
}


