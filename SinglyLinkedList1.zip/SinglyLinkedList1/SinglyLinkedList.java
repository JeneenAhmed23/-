public class SinglyLinkedList<E> {
    private Node<E>head=null;
    private Node<E>tail=null;
    private int size=0;
    public SinglyLinkedList() {}
    //public int size()
    //{return size;}
    public boolean isEmpty()
    {return size==0;}
    public E first()
    {if (isEmpty())return null;
        return head.getElement();}
    public E last()
    {if (isEmpty())return null;
        return tail.getElement();}


    public void addFirst(E e)
    {
        head= new Node<>(e,head);
        if (size==0)
            tail=head;
        size++;
    }

    public void addLast(E e)
    {
        Node<E> newest= new Node<>(e,null);
        if (size==0)
            head=newest;
        else
            tail.setNext(newest);
        tail=newest;
        size++;
    }
    public E removeFirst()
    {
        if (isEmpty())return null;
        E deleted= head.getElement();
        head=head.getNext();
        size--;
        if (size==0)
            tail=null;
        return deleted;
    }


    //1.develop an implementation of the equals method in the context of the SinglyLinkedList class
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof SinglyLinkedList)) {
            return false;
        }

        SinglyLinkedList<?> otherList = (SinglyLinkedList<?>) obj;

        if (this.size() != otherList.size()) {
            return false;
        }

        Node<E> currentNode = this.head;
        Node<?> otherNode = otherList.head;

        while (currentNode != null) {
            if (!currentNode.getElement().equals(otherNode.getElement())) {
                return false;
            }

            currentNode = currentNode.getNext();
            otherNode = otherNode.getNext();
        }

        return true;
    }

    //2.Give an algorithm for finding the second-to-last node in a singly linked list in which the last node is indicated by a null next reference
    public Node findSecond_to_last_node(Node head) {
        if (head == null || head.next == null) {
            return null;
        }

        Node current = head;
        Node previous = null;

        while (current.next != null) {
            previous = current;
            current = current.next;
        }

        return previous;
    }


    //3.Give an implementation of the size( ) method for the SingularlyLinkedList class, assuming that we did not maintain size as an instance variable
    public int size() {
        return sizeRecursive(head);
    }

    private int sizeRecursive(Node<E> node) {
        if (node == null) {
            return 0;
        }


        return 1 + sizeRecursive(node.next);
    }

    //4.Implement a rotate( ) method in the SinglyLinkedList class, which has semantics equal to addLast(removeFirst( )), yet without creating any new node
    public void rotate() {
        if (head == null || head.next == null) {

            return;
        }

        E temp = head.element;
        head = head.next;
        tail.next = new Node<>(temp);
        tail = tail.next;
        tail.next = null;
    }

    //5.Describe an algorithm for concatenating two singly linked lists L and M, into a single list L′ that contains all the nodes of L followed by all the nodes of M
    public void concatenate(SinglyLinkedList<E> list) {
        if (head == null) {
            head = list.head;
        } else if (list.head != null) {
            Node<E> current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = list.head;
        }
    }

    //6.Describe in detail an algorithm for reversing a singly linked list L using only a constant amount of additional space
    public void reverse() {
        if (head == null || head.next == null) {
            return;
        }

        Node<E> prev= null;
        Node<E> current = head;
        Node<E> next = null;

        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }

        head = prev;
    }
    private static class Node<E>{
        E element;
        Node<E>next;

        public Node(E element, Node<E> next) {
            this.element = element;
            this.next = next;
        }

        public E getElement() {
            return element;
        }

        public void setElement(E element) {
            this.element = element;
        }

        public Node<E> getNext() {
            return next;
        }

        public void setNext(Node<E> next) {
            this.next = next;
        }
    }
}


