import java.util.LinkedList;

public class LinkedStack <E> implements Stack<E>{
    LinkedList<E>l= new LinkedList<>();

    @Override
    public int size() {
        return l.size();
    }

    @Override
    public boolean isEmpty() {
        return l.isEmpty();
    }

    @Override
    public void push(E e) {
        l.addLast(e);
    }

    @Override
    public E pop() {
        return l.removeLast();
    }

    @Override
    public E top() {
        return l.getLast();
    }

    //1.Implement a method with signature transfer(S, T) that transfers all elements from stack S onto stack T, so that the element that starts at the top of S is the first to be inserted onto T, and the element at the bottom of S ends up at the top of T
    public static void transfer(Stack<Object> source, Stack<Object> target) {
        if (source.isEmpty()) {
            return;
        }

        Object element = source.pop();
        transfer(source, target);
        target.push(element);
    }
    //2.	Give a recursive method for removing all the elements from a stack
    public static void removeElements(Stack<Object> stack) {
        if (stack.isEmpty()) {
            return;
        }

        stack.pop();
        removeElements(stack);
    }

    //3.	Postfix notation is an unambiguous way of writing an arithmetic expression without parentheses. It is defined so that if “(exp1)op(exp2)” is a normal fully parenthesized expression whose operation is op, the pos Implement a method with signature transfer(S, T) that transfers all elements from stack S onto stack T, so that the element that starts at the top of S is the first to be inserted onto T, and the element at the bottom of S ends up at the top of T tfix version of this is “pexp1 pexp2 op”, where pexp1 is the postfix version of exp1 and pexp2 is the postfix version of exp2. The postfix version of a single number or variable is just that number or variable. So, for example, the postfix version of “((5 + 2) ∗ (8 − 3))/4” is “5 2 + 8 3 − ∗ 4 /”. Describe a nonrecursive way of evaluating an expression in postfix notation
    public static double evaluatePostfix(String expression) {
        Stack<Double> stack = new Stack<Double>() {
            @Override
            public int size() {
                return 0;
            }

            @Override
            public boolean isEmpty() {
                return false;
            }

            @Override
            public void push(Double aDouble) {

            }

            @Override
            public Double pop() {
                return null;
            }

            @Override
            public Double top() {
                return null;
            }
        };

        String[] tokens = expression.split(" ");

        for (String token : tokens) {
            if (isNumeric(token)) {
                stack.push(Double.parseDouble(token));
            } else {
                double operand2 = stack.pop();
                double operand1 = stack.pop();
                double result = performOperation(token, operand1, operand2);
                stack.push(result);
            }
        }

        return stack.pop();
    }

    public static boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static double performOperation(String operator, double operand1, double operand2) {
        switch (operator) {
            case "+":
                return operand1 + operand2;
            case "-":
                return operand1 - operand2;
            case "*":
                return operand1 * operand2;
            case "/":
                return operand1 / operand2;
            default:
                throw new IllegalArgumentException("Invalid operator: " + operator);
        }
    }


    //4.	Implement the clone( ) method for the ArrayStack class
    public LinkedStack<E> clone() {
        LinkedStack<E> clonedStack = new LinkedStack<>();
        LinkedList<E> temp = new LinkedList<>(l);
        while (!temp.isEmpty()) {
            clonedStack.push(temp.removeLast());
        }
        return clonedStack;
    }

}
